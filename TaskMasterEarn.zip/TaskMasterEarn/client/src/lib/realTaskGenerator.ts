import { taskBot } from './geminiApi';
import { Task, UserData } from './types';

export class RealTaskGenerator {
  private static instance: RealTaskGenerator;

  static getInstance(): RealTaskGenerator {
    if (!RealTaskGenerator.instance) {
      RealTaskGenerator.instance = new RealTaskGenerator();
    }
    return RealTaskGenerator.instance;
  }

  async generatePersonalizedRealTasks(userData: UserData): Promise<Task[]> {
    const userLevel = this.calculateUserLevel(userData);
    const difficulty = this.getDifficultyBasedOnScore(userData.userScore);
    const earningSuppression = this.getEarningSuppression(userData.userScore);

    const prompt = `Generate 3 REAL actionable tasks for a user with these characteristics:
    - User Score: ${userData.userScore}/100 (${userLevel} level)
    - Tasks Completed: ${userData.tasksCompleted}
    - Skill Levels: Coding(${userData.skillLevels.coding}), Writing(${userData.skillLevels.writing}), Photography(${userData.skillLevels.photography})
    
    Based on user score, apply these rules:
    - Score 0-30: Very basic tasks, low earnings (₹2-5)
    - Score 31-60: Medium tasks, moderate earnings (₹8-14) 
    - Score 61-100: Advanced tasks, higher earnings (₹15-25)
    
    Generate REAL tasks like:
    1. Photography: "Take 7 photos of local street art in your city" (requires camera/gallery)
    2. Writing: "Write a 200-word review of a local restaurant you visited" 
    3. Research: "Find and document 5 trending hashtags in fashion this week"
    4. Coding: "Create a simple JavaScript function to validate email addresses"
    5. Social Media: "Create an Instagram post about sustainable living with 3 photos"
    
    For each task, specify:
    - Required actions (camera, gallery, location, microphone, etc.)
    - Specific deliverables
    - Real-world impact
    
    Format as JSON array:
    [
      {
        "title": "Take 7 photos of street art",
        "description": "Capture diverse street art in your local area. Each photo should show different artistic styles.",
        "category": "Photography", 
        "estimatedTime": 45,
        "difficulty": "${difficulty}",
        "requiredActions": ["camera", "gallery", "location"],
        "instructions": ["Find 7 different street art pieces", "Take high-quality photos", "Ensure good lighting", "Include variety in artistic styles"],
        "taskData": {
          "photoCount": 7,
          "theme": "street art",
          "qualityRequirements": ["good lighting", "clear focus", "artistic variety"]
        }
      }
    ]`;

    try {
      const result = await taskBot.generativeModel.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (!jsonMatch) {
        throw new Error('Failed to parse tasks');
      }
      
      const tasksData = JSON.parse(jsonMatch[0]);
      
      return tasksData.map((task: any, index: number) => ({
        id: `real-task-${Date.now()}-${index}`,
        title: task.title,
        description: task.description,
        category: task.category,
        icon: this.getIconForCategory(task.category),
        type: task.category.toLowerCase().replace(/\s+/g, '_'),
        reward: this.calculateReward(task.difficulty, task.estimatedTime, earningSuppression),
        completed: false,
        status: 'pending' as const,
        generatedAt: Date.now(),
        estimatedTime: task.estimatedTime,
        difficulty: task.difficulty,
        instructions: task.instructions,
        requiredActions: task.requiredActions || [],
        isRealTask: true,
        taskData: task.taskData
      }));
    } catch (error) {
      console.error('Failed to generate real tasks:', error);
      return [];
    }
  }

  private calculateUserLevel(userData: UserData): string {
    if (userData.userScore >= 80) return 'Expert';
    if (userData.userScore >= 60) return 'Advanced';
    if (userData.userScore >= 40) return 'Intermediate';
    return 'Beginner';
  }

  private getDifficultyBasedOnScore(score: number): string {
    if (score >= 70) return 'hard';
    if (score >= 40) return 'medium';
    return 'easy';
  }

  private getEarningSuppression(score: number): number {
    // Lower score = lower earnings multiplier
    if (score >= 60) return 1.0; // Normal earnings
    if (score >= 30) return 0.7; // 30% reduction
    return 0.4; // 60% reduction for poor performers
  }

  private calculateReward(difficulty: string, timeMinutes: number, suppression: number): number {
    const baseRates = {
      easy: 0.3,    // ₹0.3 per minute
      medium: 0.5,  // ₹0.5 per minute  
      hard: 0.8     // ₹0.8 per minute
    };
    
    const rate = baseRates[difficulty as keyof typeof baseRates] || 0.3;
    const baseReward = timeMinutes * rate;
    const suppressedReward = baseReward * suppression;
    
    // Apply score-based caps
    let minReward, maxReward;
    if (suppression <= 0.4) {
      minReward = 2; maxReward = 5;   // Poor performers
    } else if (suppression <= 0.7) {
      minReward = 8; maxReward = 14;  // Average performers
    } else {
      minReward = 15; maxReward = 25; // Good performers
    }
    
    return Math.max(minReward, Math.min(maxReward, Math.round(suppressedReward)));
  }

  private getIconForCategory(category: string): string {
    const categoryIcons = {
      'Photography': 'Camera',
      'Writing': 'PenTool',
      'Research': 'Search',
      'Coding': 'Code',
      'Social Media': 'Share',
      'Content Creation': 'Edit',
      'Data Entry': 'FileText',
      'Creative': 'Palette'
    };
    return categoryIcons[category as keyof typeof categoryIcons] || 'Circle';
  }
}

export const realTaskGenerator = RealTaskGenerator.getInstance();