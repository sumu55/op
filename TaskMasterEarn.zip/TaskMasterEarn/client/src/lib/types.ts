export interface UserData {
  name: string;
  balance: number;
  profilePic: string | null;
  tasksCompleted: number;
  verified: boolean;
  userScore: number; // 0-100 based on task performance
  taskHistory: TaskPerformance[];
  skillLevels: {
    coding: number;
    writing: number;
    photography: number;
    research: number;
    creative: number;
  };
  feedback?: {
    rating: number;
    text: string;
  };
  answers?: {
    math: string;
    color: string;
    week: string;
  };
}

export interface TaskPerformance {
  taskId: string;
  score: number; // 0-100
  completedAt: number;
  taskType: string;
  earnedAmount: number;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  category?: string;
  icon: string;
  type: string;
  reward: number;
  completed: boolean;
  estimatedTime?: number;
  difficulty?: 'easy' | 'medium' | 'hard';
  instructions?: string[];
  status: 'pending' | 'accepted' | 'rejected' | 'completed' | 'submitted' | 'reviewing';
  generatedAt: number;
  acceptedAt?: number;
  completedAt?: number;
  submittedAt?: number;
  submission?: string;
  submissionFiles?: string[];
  reviewScore?: number;
  reviewFeedback?: string;
  requiredActions?: string[]; // e.g., ['camera', 'gallery', 'location', 'microphone']
  isRealTask: boolean;
  taskData?: any; // Additional task-specific data
}

export interface WithdrawalData {
  method: 'upi' | 'bank';
  upiId?: string;
  upiMobile?: string;
  bankName?: string;
  ifscCode?: string;
  bankNameField?: string;
  accountNumber?: string;
}
