import { taskBot } from './geminiApi';
import { Task, UserData, TaskPerformance } from './types';

export class TaskReviewer {
  private static instance: TaskReviewer;

  static getInstance(): TaskReviewer {
    if (!TaskReviewer.instance) {
      TaskReviewer.instance = new TaskReviewer();
    }
    return TaskReviewer.instance;
  }

  async reviewTaskSubmission(task: Task, submission: string, submissionFiles?: string[]): Promise<{
    score: number;
    feedback: string;
    earnedAmount: number;
    approved: boolean;
  }> {
    const prompt = `You are an expert task reviewer. Review this submission and provide a detailed assessment.

Task Details:
- Title: ${task.title}
- Description: ${task.description}
- Expected Reward: ₹${task.reward}
- Difficulty: ${task.difficulty}
- Instructions: ${task.instructions?.join(', ')}

User Submission:
"${submission}"

Evaluate based on:
1. Completeness (Did they follow all instructions?)
2. Quality (Is the work well done?)
3. Effort (Did they put in genuine effort?)
4. Accuracy (Is the submission correct/relevant?)

Scoring Guidelines:
- 90-100: Exceptional work, exceeds expectations
- 80-89: Good work, meets all requirements  
- 70-79: Satisfactory work, meets most requirements
- 60-69: Below average, missing key elements
- 50-59: Poor work, barely acceptable
- 0-49: Unacceptable, reject payment

Payment Rules:
- Score 80+: Full payment (100% of reward)
- Score 70-79: Good payment (80% of reward)
- Score 60-69: Reduced payment (60% of reward)
- Score 50-59: Minimal payment (40% of reward)
- Score <50: No payment (0% of reward)

Respond in JSON format:
{
  "score": 85,
  "feedback": "Detailed feedback explaining the score",
  "paymentPercentage": 100,
  "approved": true,
  "improvements": ["Suggestion 1", "Suggestion 2"]
}`;

    try {
      const result = await taskBot.generativeModel.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('Failed to parse review result');
      }
      
      const reviewData = JSON.parse(jsonMatch[0]);
      const earnedAmount = Math.round((task.reward * reviewData.paymentPercentage) / 100);
      
      return {
        score: reviewData.score,
        feedback: reviewData.feedback,
        earnedAmount,
        approved: reviewData.approved
      };
    } catch (error) {
      console.error('Failed to review task:', error);
      // Fallback review for API failures
      return this.fallbackReview(task, submission);
    }
  }

  private fallbackReview(task: Task, submission: string): {
    score: number;
    feedback: string;
    earnedAmount: number;
    approved: boolean;
  } {
    // Simple fallback scoring based on submission length and task complexity
    const submissionWords = submission.split(' ').length;
    const expectedWords = this.getExpectedWords(task);
    
    let score = 50; // Base score
    
    // Adjust based on submission length
    if (submissionWords >= expectedWords) score += 20;
    else if (submissionWords >= expectedWords * 0.7) score += 10;
    
    // Adjust based on task difficulty
    if (task.difficulty === 'easy') score += 10;
    else if (task.difficulty === 'hard') score += 5;
    
    // Cap the score
    score = Math.min(85, Math.max(40, score));
    
    const paymentPercentage = this.getPaymentPercentage(score);
    const earnedAmount = Math.round((task.reward * paymentPercentage) / 100);
    
    return {
      score,
      feedback: `Submission reviewed. Score: ${score}/100. ${score >= 70 ? 'Good work!' : 'Consider improving quality and completeness.'}`,
      earnedAmount,
      approved: score >= 50
    };
  }

  private getExpectedWords(task: Task): number {
    const baseWords = {
      easy: 50,
      medium: 100,
      hard: 150
    };
    
    return baseWords[task.difficulty || 'medium'];
  }

  private getPaymentPercentage(score: number): number {
    if (score >= 80) return 100;
    if (score >= 70) return 80;
    if (score >= 60) return 60;
    if (score >= 50) return 40;
    return 0;
  }

  updateUserPerformance(userData: UserData, taskPerformance: TaskPerformance): UserData {
    const updatedHistory = [...userData.taskHistory, taskPerformance];
    
    // Calculate new user score (weighted average of recent performances)
    const recentTasks = updatedHistory.slice(-10); // Last 10 tasks
    const averageScore = recentTasks.reduce((sum, task) => sum + task.score, 0) / recentTasks.length;
    
    // Update skill level for specific task type
    const updatedSkillLevels = { ...userData.skillLevels };
    const skillType = this.mapTaskTypeToSkill(taskPerformance.taskType);
    if (skillType && updatedSkillLevels[skillType]) {
      updatedSkillLevels[skillType] = Math.min(10, updatedSkillLevels[skillType] + 
        (taskPerformance.score >= 80 ? 0.2 : taskPerformance.score >= 60 ? 0.1 : 0));
    }
    
    return {
      ...userData,
      userScore: Math.round(averageScore),
      taskHistory: updatedHistory,
      skillLevels: updatedSkillLevels,
      tasksCompleted: userData.tasksCompleted + 1
    };
  }

  private mapTaskTypeToSkill(taskType: string): keyof UserData['skillLevels'] | null {
    const mapping: Record<string, keyof UserData['skillLevels']> = {
      'coding': 'coding',
      'programming': 'coding',
      'writing': 'writing',
      'content_creation': 'writing',
      'photography': 'photography',
      'research': 'research',
      'research_tasks': 'research',
      'creative': 'creative',
      'creative_tasks': 'creative'
    };
    
    return mapping[taskType.toLowerCase()] || null;
  }
}

export const taskReviewer = TaskReviewer.getInstance();