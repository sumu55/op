import { UserData, Task } from './types';

const STORAGE_KEY = 'taskForMeUser';
const TASKS_KEY = 'taskForMeTasks';

export const defaultUserData: UserData = {
  name: 'User',
  balance: 0,
  profilePic: null,
  tasksCompleted: 0,
  verified: false,
  userScore: 50, // Starting score
  taskHistory: [],
  skillLevels: {
    coding: 1,
    writing: 1,
    photography: 1,
    research: 1,
    creative: 1,
  },
};

export const saveUserData = (userData: UserData): void => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(userData));
};

export const getUserData = (): UserData => {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    return { ...defaultUserData, ...JSON.parse(saved) };
  }
  return defaultUserData;
};

export const saveTasks = (tasks: Task[]): void => {
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
};

export const getTasks = (): Task[] => {
  const saved = localStorage.getItem(TASKS_KEY);
  return saved ? JSON.parse(saved) : [];
};

export const generateTasks = (): Task[] => {
  const taskTemplates = [
    { title: 'Watch a short video', icon: 'Play', type: 'video', description: 'Watch a recommended video and provide feedback' },
    { title: 'Answer a quick survey', icon: 'ClipboardList', type: 'survey', description: 'Complete a short survey about your preferences' },
    { title: 'Rate our app', icon: 'Star', type: 'rating', description: 'Rate and review our app on the store' },
    { title: 'Share with friends', icon: 'Share', type: 'share', description: 'Share the app with your friends on social media' },
    { title: 'Complete profile', icon: 'UserCheck', type: 'profile', description: 'Complete your profile information' },
    { title: 'Daily check-in', icon: 'CalendarCheck', type: 'checkin', description: 'Check in daily to earn bonus points' },
    { title: 'Try a new feature', icon: 'Sparkles', type: 'feature', description: 'Test and provide feedback on new features' },
    { title: 'Provide feedback', icon: 'MessageCircle', type: 'feedback', description: 'Share your feedback about the app experience' },
  ];

  const numTasks = Math.floor(Math.random() * 4) + 5; // 5-8 tasks
  const selectedTasks = taskTemplates
    .sort(() => 0.5 - Math.random())
    .slice(0, numTasks);

  return selectedTasks.map((template, index) => ({
    id: `task-${Date.now()}-${index}`,
    ...template,
    reward: Math.floor(Math.random() * 100) + 1, // ₹1-₹100
    completed: false,
    status: 'pending' as const,
    generatedAt: Date.now(),
    estimatedTime: Math.floor(Math.random() * 25) + 5, // 5-30 minutes
    difficulty: ['easy', 'medium', 'hard'][Math.floor(Math.random() * 3)] as 'easy' | 'medium' | 'hard',
    isRealTask: false, // These are fallback tasks
  }));
};
