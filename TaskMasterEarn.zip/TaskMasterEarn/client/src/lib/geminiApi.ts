import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = 'AIzaSyAPIC9ecfRgwXBeilkA_7-q-jEwq-ov_e8';
const genAI = new GoogleGenerativeAI(API_KEY);

export interface GeneratedTask {
  title: string;
  description: string;
  category: string;
  estimatedTime: number; // in minutes
  reward: number;
  difficulty: 'easy' | 'medium' | 'hard';
  instructions: string[];
}

export class TaskBot {
  private model = genAI.getGenerativeModel({ model: 'gemini-pro' });

  get generativeModel() {
    return this.model;
  }

  async generateTasks(count: number = 5, userProfile?: any): Promise<GeneratedTask[]> {
    const prompt = `Generate ${count} diverse and engaging micro-tasks for a task completion app. 
    Each task should be something a user can complete on their mobile device within 5-30 minutes.
    
    Consider these categories:
    - Social media engagement (like, share, comment)
    - Content creation (write reviews, take photos)
    - Learning activities (watch videos, read articles)
    - Survey participation
    - App testing
    - Data entry
    - Creative tasks (design, writing)
    - Research tasks
    
    For each task, provide:
    1. Title (concise, action-oriented)
    2. Description (2-3 sentences explaining what to do)
    3. Category (one of the categories above)
    4. Estimated time in minutes (5-30)
    5. Difficulty level (easy, medium, hard)
    6. Step-by-step instructions (3-5 bullet points)
    
    Make tasks realistic, achievable, and varied. Avoid repetitive tasks.
    
    Respond in this exact JSON format:
    [
      {
        "title": "Task title",
        "description": "Task description",
        "category": "category name",
        "estimatedTime": 15,
        "difficulty": "easy",
        "instructions": ["Step 1", "Step 2", "Step 3"]
      }
    ]`;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Extract JSON from response
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (!jsonMatch) {
        throw new Error('Failed to parse task data from response');
      }
      
      const tasks: any[] = JSON.parse(jsonMatch[0]);
      
      return tasks.map(task => ({
        ...task,
        reward: this.calculateReward(task.difficulty, task.estimatedTime)
      }));
    } catch (error) {
      console.error('Error generating tasks:', error);
      // Fallback to manual tasks if API fails
      return this.getFallbackTasks();
    }
  }

  private calculateReward(difficulty: string, timeMinutes: number): number {
    const baseRate = {
      easy: 2,
      medium: 4,
      hard: 6
    };
    
    const rate = baseRate[difficulty as keyof typeof baseRate] || 2;
    const reward = Math.ceil(timeMinutes * rate * (0.8 + Math.random() * 0.4));
    
    // Ensure reward is within ₹1-₹100 range
    return Math.max(1, Math.min(100, reward));
  }

  private getFallbackTasks(): GeneratedTask[] {
    return [
      {
        title: "Rate a mobile app",
        description: "Download and rate a popular app on the Play Store. Write a helpful review based on your experience.",
        category: "App testing",
        estimatedTime: 10,
        reward: 25,
        difficulty: "easy",
        instructions: [
          "Download the suggested app from Play Store",
          "Use the app for 5-10 minutes",
          "Write an honest review (minimum 50 words)",
          "Rate the app with appropriate stars"
        ]
      },
      {
        title: "Create social media content",
        description: "Take a creative photo and post it on your social media with specific hashtags.",
        category: "Content creation",
        estimatedTime: 15,
        reward: 35,
        difficulty: "medium",
        instructions: [
          "Take a high-quality photo of your daily activity",
          "Add creative caption with provided hashtags",
          "Post on your preferred social media platform",
          "Share the post link as proof"
        ]
      }
    ];
  }

  async generatePersonalizedTasks(userInterests: string[], completedTasks: number): Promise<GeneratedTask[]> {
    const interests = userInterests.join(', ');
    const experienceLevel = completedTasks < 5 ? 'beginner' : completedTasks < 20 ? 'intermediate' : 'experienced';
    
    const prompt = `Generate 3 personalized tasks for a user who is interested in: ${interests}
    User experience level: ${experienceLevel} (completed ${completedTasks} tasks)
    
    Make tasks relevant to their interests and appropriate for their experience level.
    ${experienceLevel === 'beginner' ? 'Focus on simple, easy-to-understand tasks.' : ''}
    ${experienceLevel === 'experienced' ? 'Include more challenging and creative tasks.' : ''}
    
    Use the same JSON format as before.`;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (!jsonMatch) {
        return this.getFallbackTasks().slice(0, 3);
      }
      
      const tasks: any[] = JSON.parse(jsonMatch[0]);
      return tasks.map(task => ({
        ...task,
        reward: this.calculateReward(task.difficulty, task.estimatedTime)
      }));
    } catch (error) {
      console.error('Error generating personalized tasks:', error);
      return this.getFallbackTasks().slice(0, 3);
    }
  }
}

export const taskBot = new TaskBot();