import { taskBot } from './geminiApi';
import { Task } from './types';
import { saveTasks, getTasks } from './storage';

export class TaskQueue {
  private static instance: TaskQueue;
  private isGenerating = false;
  private listeners: Array<(tasks: Task[]) => void> = [];
  private notificationListeners: Array<(message: string) => void> = [];

  static getInstance(): TaskQueue {
    if (!TaskQueue.instance) {
      TaskQueue.instance = new TaskQueue();
    }
    return TaskQueue.instance;
  }

  addTaskListener(listener: (tasks: Task[]) => void) {
    this.listeners.push(listener);
  }

  removeTaskListener(listener: (tasks: Task[]) => void) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }

  addNotificationListener(listener: (message: string) => void) {
    this.notificationListeners.push(listener);
  }

  removeNotificationListener(listener: (message: string) => void) {
    this.notificationListeners = this.notificationListeners.filter(l => l !== listener);
  }

  private notifyListeners(tasks: Task[]) {
    this.listeners.forEach(listener => listener(tasks));
  }

  private notifyNewTask(message: string) {
    this.notificationListeners.forEach(listener => listener(message));
  }

  async generateBackgroundTasks(): Promise<void> {
    if (this.isGenerating) return;

    this.isGenerating = true;
    
    try {
      // Generate tasks silently in background
      const generatedTasks = await taskBot.generateTasks(3);
      const currentTasks = getTasks();
      
      const newTasks: Task[] = generatedTasks.map((task, index) => ({
        id: `bg-task-${Date.now()}-${index}`,
        title: task.title,
        description: task.description,
        category: task.category,
        icon: this.getIconForCategory(task.category),
        type: task.category?.toLowerCase().replace(/\s+/g, '_') || 'general',
        reward: task.reward,
        completed: false,
        status: 'pending',
        generatedAt: Date.now(),
        estimatedTime: task.estimatedTime,
        difficulty: task.difficulty,
        instructions: task.instructions,
        isRealTask: true,
        requiredActions: [],
      }));

      // Add new tasks to existing ones
      const allTasks = [...currentTasks, ...newTasks];
      saveTasks(allTasks);
      
      // Notify listeners about new tasks
      this.notifyListeners(allTasks);
      this.notifyNewTask(`${newTasks.length} new tasks available!`);
      
    } catch (error) {
      console.error('Background task generation failed:', error);
    } finally {
      this.isGenerating = false;
    }
  }

  private getIconForCategory(category: string): string {
    const categoryIcons = {
      'Social media engagement': 'Share',
      'Content creation': 'MessageCircle',
      'Learning activities': 'Play',
      'Survey participation': 'ClipboardList',
      'App testing': 'Sparkles',
      'Data entry': 'UserCheck',
      'Creative tasks': 'Star',
      'Research tasks': 'CalendarCheck',
      'Programming': 'Code',
      'Writing': 'PenTool',
      'Design': 'Palette',
    };
    return categoryIcons[category as keyof typeof categoryIcons] || 'Play';
  }

  // Auto-generate tasks at intervals
  startAutoGeneration(intervalMinutes: number = 30): void {
    const interval = setInterval(async () => {
      const currentTasks = getTasks();
      const pendingTasks = currentTasks.filter(t => t.status === 'pending');
      
      // Generate new tasks if we have less than 2 pending tasks
      if (pendingTasks.length < 2) {
        await this.generateBackgroundTasks();
      }
    }, intervalMinutes * 60 * 1000);

    // Store interval ID for cleanup if needed
    (window as any).taskGenerationInterval = interval;
  }

  async generateSpecificTask(type: 'coding' | 'writing' | 'research' | 'creative'): Promise<Task | null> {
    if (this.isGenerating) return null;

    this.isGenerating = true;

    try {
      const prompt = this.getPromptForTaskType(type);
      const result = await taskBot.generativeModel.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('Failed to parse task data');
      }
      
      const taskData = JSON.parse(jsonMatch[0]);
      
      const newTask: Task = {
        id: `specific-${type}-${Date.now()}`,
        title: taskData.title,
        description: taskData.description,
        category: taskData.category,
        icon: this.getIconForCategory(taskData.category),
        type: type,
        reward: this.calculateReward(taskData.difficulty, taskData.estimatedTime),
        completed: false,
        status: 'pending',
        generatedAt: Date.now(),
        estimatedTime: taskData.estimatedTime,
        difficulty: taskData.difficulty,
        instructions: taskData.instructions,
        isRealTask: true,
        requiredActions: [],
      };

      // Add to existing tasks
      const currentTasks = getTasks();
      const updatedTasks = [...currentTasks, newTask];
      saveTasks(updatedTasks);
      
      this.notifyListeners(updatedTasks);
      this.notifyNewTask(`New ${type} task available!`);
      
      return newTask;
    } catch (error) {
      console.error(`Failed to generate ${type} task:`, error);
      return null;
    } finally {
      this.isGenerating = false;
    }
  }

  private getPromptForTaskType(type: string): string {
    const prompts = {
      coding: `Generate a coding task for a mobile app user. The task should be something they can complete and submit via text/code. 
      Examples: "Write a simple chatbot function", "Create a basic calculator in Python", "Write HTML for a contact form"
      
      Respond in this JSON format:
      {
        "title": "Write a simple chatbot function",
        "description": "Create a basic chatbot function that responds to greetings",
        "category": "Programming",
        "estimatedTime": 20,
        "difficulty": "medium",
        "instructions": ["Write a function named 'chatbot'", "Handle greetings like 'hello', 'hi'", "Return appropriate responses", "Test with sample inputs"]
      }`,
      
      writing: `Generate a writing task for a mobile app user. 
      Examples: "Write a product review", "Create a social media post", "Write a short story"
      
      Use the same JSON format with category "Content creation"`,
      
      research: `Generate a research task for a mobile app user.
      Examples: "Research trending topics", "Find information about a company", "Compare product features"
      
      Use the same JSON format with category "Research tasks"`,
      
      creative: `Generate a creative task for a mobile app user.
      Examples: "Design a logo concept", "Create a slogan", "Write a poem"
      
      Use the same JSON format with category "Creative tasks"`
    };
    
    return prompts[type as keyof typeof prompts] || prompts.coding;
  }

  private calculateReward(difficulty: string, timeMinutes: number): number {
    const baseRate = { easy: 3, medium: 5, hard: 8 };
    const rate = baseRate[difficulty as keyof typeof baseRate] || 3;
    const reward = Math.ceil(timeMinutes * rate * (0.8 + Math.random() * 0.4));
    return Math.max(5, Math.min(100, reward));
  }
}

export const taskQueue = TaskQueue.getInstance();