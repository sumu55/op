import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect, useState } from "react";
import { getUserData } from "./lib/storage";
import SplashScreen from "./pages/splash";
import HomePage from "./pages/home";
import VerificationPage from "./pages/verification";
import DashboardPage from "./pages/dashboard";
import NotFound from "./pages/not-found";

function Router() {
  const [isLoading, setIsLoading] = useState(true);
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    // Check if user is verified
    const userData = getUserData();
    setIsVerified(userData.verified);
    
    // Show splash screen for 3 seconds
    setTimeout(() => {
      setIsLoading(false);
    }, 3000);
  }, []);

  if (isLoading) {
    return <SplashScreen />;
  }

  return (
    <Switch>
      <Route path="/" component={isVerified ? DashboardPage : HomePage} />
      <Route path="/verification" component={VerificationPage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
