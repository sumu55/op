import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SuccessModal({ isOpen, onClose }: SuccessModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-sm">
        <div className="text-center p-8 animate-bounce-in">
          <div className="w-20 h-20 success-gradient rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-4">Withdrawal Successful!</h3>
          <p className="text-gray-600 mb-6">Your amount will be credited within 10 minutes.</p>
          <Button onClick={onClose} className="w-full bg-primary text-white font-semibold py-3">
            Continue Earning
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
