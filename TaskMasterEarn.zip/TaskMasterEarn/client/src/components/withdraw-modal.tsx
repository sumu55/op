import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Smartphone, Building, IndianRupee, Loader2 } from "lucide-react";
import { WithdrawalData } from "@/lib/types";

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  currentBalance: number;
}

export default function WithdrawModal({ isOpen, onClose, onSuccess, currentBalance }: WithdrawModalProps) {
  const [selectedMethod, setSelectedMethod] = useState<'upi' | 'bank' | ''>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState<WithdrawalData>({
    method: 'upi',
  });

  const handleMethodSelect = (method: 'upi' | 'bank') => {
    setSelectedMethod(method);
    setFormData(prev => ({ ...prev, method }));
  };

  const handleInputChange = (field: keyof WithdrawalData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    setIsProcessing(true);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setIsProcessing(false);
    onSuccess();
    
    // Reset form
    setSelectedMethod('');
    setFormData({ method: 'upi' });
  };

  const isFormValid = () => {
    if (selectedMethod === 'upi') {
      return formData.upiId && formData.upiMobile;
    } else if (selectedMethod === 'bank') {
      return formData.bankName && formData.ifscCode && formData.bankNameField && formData.accountNumber;
    }
    return false;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-800">Withdraw Money</DialogTitle>
        </DialogHeader>
        
        <div className="p-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 success-gradient rounded-full flex items-center justify-center mx-auto mb-4">
              <IndianRupee className="w-8 h-8 text-white" />
            </div>
            <p className="text-gray-600">
              Available Balance: <span className="font-bold text-secondary">₹{currentBalance}</span>
            </p>
          </div>
          
          {/* Method Selection */}
          <div className="mb-6">
            <p className="font-medium text-gray-800 mb-3">Select Withdrawal Method:</p>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant={selectedMethod === 'upi' ? 'default' : 'outline'}
                onClick={() => handleMethodSelect('upi')}
                className="p-4 h-auto flex-col space-y-2 border-2"
              >
                <Smartphone className="w-8 h-8" />
                <span className="font-medium">UPI</span>
              </Button>
              <Button
                variant={selectedMethod === 'bank' ? 'default' : 'outline'}
                onClick={() => handleMethodSelect('bank')}
                className="p-4 h-auto flex-col space-y-2 border-2"
              >
                <Building className="w-8 h-8" />
                <span className="font-medium">Bank</span>
              </Button>
            </div>
          </div>
          
          {/* UPI Form */}
          {selectedMethod === 'upi' && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="upiId">UPI ID</Label>
                <Input
                  id="upiId"
                  placeholder="example@paytm"
                  value={formData.upiId || ''}
                  onChange={(e) => handleInputChange('upiId', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="upiMobile">Mobile Number</Label>
                <Input
                  id="upiMobile"
                  type="tel"
                  placeholder="9876543210"
                  value={formData.upiMobile || ''}
                  onChange={(e) => handleInputChange('upiMobile', e.target.value)}
                />
              </div>
            </div>
          )}
          
          {/* Bank Form */}
          {selectedMethod === 'bank' && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="bankName">Full Name</Label>
                <Input
                  id="bankName"
                  placeholder="As per bank account"
                  value={formData.bankName || ''}
                  onChange={(e) => handleInputChange('bankName', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="ifscCode">IFSC Code</Label>
                <Input
                  id="ifscCode"
                  placeholder="SBIN0001234"
                  value={formData.ifscCode || ''}
                  onChange={(e) => handleInputChange('ifscCode', e.target.value.toUpperCase())}
                />
              </div>
              <div>
                <Label htmlFor="bankNameField">Bank Name</Label>
                <Input
                  id="bankNameField"
                  placeholder="State Bank of India"
                  value={formData.bankNameField || ''}
                  onChange={(e) => handleInputChange('bankNameField', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="accountNumber">Account Number</Label>
                <Input
                  id="accountNumber"
                  placeholder="1234567890123456"
                  value={formData.accountNumber || ''}
                  onChange={(e) => handleInputChange('accountNumber', e.target.value)}
                />
              </div>
            </div>
          )}
          
          {selectedMethod && (
            <Button
              onClick={handleSubmit}
              disabled={!isFormValid() || isProcessing}
              className="w-full success-gradient text-white font-semibold py-3 mt-6"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                'Withdraw Now'
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
