import { useState, useEffect } from "react";
import { Bell, BellRing } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface NotificationBellProps {
  hasNewTasks: boolean;
  newTaskCount: number;
  onClick: () => void;
}

export default function NotificationBell({ hasNewTasks, newTaskCount, onClick }: NotificationBellProps) {
  const [isRinging, setIsRinging] = useState(false);

  useEffect(() => {
    if (hasNewTasks && newTaskCount > 0) {
      setIsRinging(true);
      const timer = setTimeout(() => setIsRinging(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [hasNewTasks, newTaskCount]);

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={onClick}
      className={`relative text-white bg-white/20 hover:bg-white/30 ${
        isRinging ? 'animate-bounce' : ''
      }`}
    >
      {hasNewTasks ? (
        <BellRing className="w-5 h-5" />
      ) : (
        <Bell className="w-5 h-5" />
      )}
      
      {newTaskCount > 0 && (
        <Badge 
          className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center bg-red-500 text-white text-xs animate-pulse"
        >
          {newTaskCount > 9 ? '9+' : newTaskCount}
        </Badge>
      )}
    </Button>
  );
}