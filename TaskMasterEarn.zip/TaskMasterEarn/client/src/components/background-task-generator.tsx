import { useEffect } from "react";
import { taskQueue } from "@/lib/taskQueue";

interface BackgroundTaskGeneratorProps {
  isActive: boolean;
}

export default function BackgroundTaskGenerator({ isActive }: BackgroundTaskGeneratorProps) {
  useEffect(() => {
    if (!isActive) return;

    // Generate coding tasks periodically
    const generateCodingTask = () => {
      taskQueue.generateSpecificTask('coding');
    };

    // Generate writing tasks
    const generateWritingTask = () => {
      taskQueue.generateSpecificTask('writing');
    };

    // Generate research tasks
    const generateResearchTask = () => {
      taskQueue.generateSpecificTask('research');
    };

    // Generate creative tasks
    const generateCreativeTask = () => {
      taskQueue.generateSpecificTask('creative');
    };

    // Set up intervals for different task types
    const codingInterval = setInterval(generateCodingTask, 10 * 60 * 1000); // Every 10 minutes
    const writingInterval = setInterval(generateWritingTask, 15 * 60 * 1000); // Every 15 minutes
    const researchInterval = setInterval(generateResearchTask, 20 * 60 * 1000); // Every 20 minutes
    const creativeInterval = setInterval(generateCreativeTask, 25 * 60 * 1000); // Every 25 minutes

    // Generate initial tasks after a short delay
    setTimeout(generateCodingTask, 5000); // 5 seconds
    setTimeout(generateWritingTask, 10000); // 10 seconds

    return () => {
      clearInterval(codingInterval);
      clearInterval(writingInterval);
      clearInterval(researchInterval);
      clearInterval(creativeInterval);
    };
  }, [isActive]);

  // This component doesn't render anything
  return null;
}