import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Clock, CheckCircle, X, Play, ClipboardList, Star, Share, UserCheck, CalendarCheck, Sparkles, MessageCircle, AlertCircle } from "lucide-react";
import { Task } from "@/lib/types";

const iconMap = {
  Play,
  ClipboardList, 
  Star,
  Share,
  UserCheck,
  CalendarCheck,
  Sparkles,
  MessageCircle,
};

interface TaskCardProps {
  task: Task;
  onAccept: (taskId: string) => void;
  onReject: (taskId: string) => void;
  onComplete: (taskId: string) => void;
  isProcessing?: boolean;
}

export default function TaskCard({ task, onAccept, onReject, onComplete, isProcessing }: TaskCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  const getTaskIcon = (iconName: string) => {
    const IconComponent = iconMap[iconName as keyof typeof iconMap] || Play;
    return <IconComponent className="w-5 h-5 text-primary" />;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-blue-100 text-blue-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'completed': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <>
      <Card className="shadow-sm border-0 hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center">
                {getTaskIcon(task.icon)}
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-gray-800 text-sm">{task.title}</h4>
                {task.description && (
                  <p className="text-xs text-gray-600 mt-1 line-clamp-2">{task.description}</p>
                )}
              </div>
            </div>
            <div className="flex flex-col items-end space-y-1">
              <p className="text-sm font-bold text-secondary">₹{task.reward}</p>
              {task.estimatedTime && (
                <div className="flex items-center text-xs text-gray-500">
                  <Clock className="w-3 h-3 mr-1" />
                  {task.estimatedTime}m
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between mb-3">
            <div className="flex space-x-2">
              <Badge variant="secondary" className={getDifficultyColor(task.difficulty || 'easy')}>
                {task.difficulty || 'easy'}
              </Badge>
              <Badge variant="outline" className={getStatusColor(task.status)}>
                {task.status}
              </Badge>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDetails(true)}
              className="text-xs"
            >
              View Details
            </Button>
          </div>

          {task.status === 'pending' && (
            <div className="flex space-x-2">
              <Button
                onClick={() => onReject(task.id)}
                variant="outline"
                size="sm"
                className="flex-1 text-red-600 border-red-200 hover:bg-red-50"
              >
                <X className="w-4 h-4 mr-1" />
                Reject
              </Button>
              <Button
                onClick={() => onAccept(task.id)}
                size="sm"
                className="flex-1 bg-primary hover:bg-blue-700"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Accept
              </Button>
            </div>
          )}

          {task.status === 'accepted' && (
            <Button
              onClick={() => onComplete(task.id)}
              disabled={isProcessing}
              className="w-full bg-secondary hover:bg-green-700"
            >
              {isProcessing ? (
                <>
                  <AlertCircle className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Complete Task
                </>
              )}
            </Button>
          )}

          {task.status === 'completed' && (
            <Button disabled className="w-full bg-gray-100 text-gray-500">
              <CheckCircle className="w-4 h-4 mr-2" />
              Completed
            </Button>
          )}

          {task.status === 'rejected' && (
            <Button disabled className="w-full bg-red-100 text-red-500">
              <X className="w-4 h-4 mr-2" />
              Rejected
            </Button>
          )}
        </CardContent>
      </Card>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="w-full max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              {getTaskIcon(task.icon)}
              <span>{task.title}</span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-800 mb-2">Description</h4>
              <p className="text-sm text-gray-600">{task.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-gray-800 mb-1">Reward</h4>
                <p className="text-lg font-bold text-secondary">₹{task.reward}</p>
              </div>
              <div>
                <h4 className="font-medium text-gray-800 mb-1">Time</h4>
                <p className="text-sm text-gray-600">{task.estimatedTime || 15} minutes</p>
              </div>
            </div>

            <div className="flex space-x-2">
              <Badge className={getDifficultyColor(task.difficulty || 'easy')}>
                {task.difficulty || 'easy'}
              </Badge>
              <Badge variant="outline" className={getStatusColor(task.status)}>
                {task.status}
              </Badge>
            </div>

            {task.instructions && task.instructions.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-800 mb-2">Instructions</h4>
                <ul className="space-y-1">
                  {task.instructions.map((instruction, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-start">
                      <span className="w-4 h-4 bg-primary rounded-full text-white text-xs flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">
                        {index + 1}
                      </span>
                      {instruction}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}