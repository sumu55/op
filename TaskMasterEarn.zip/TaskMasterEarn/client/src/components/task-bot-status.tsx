import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Zap, Clock, TrendingUp } from "lucide-react";

interface TaskBotStatusProps {
  tasksGenerated: number;
  isActive: boolean;
  lastActivity: number;
}

export default function TaskBotStatus({ tasksGenerated, isActive, lastActivity }: TaskBotStatusProps) {
  const [timeAgo, setTimeAgo] = useState<string>("");

  useEffect(() => {
    const updateTimeAgo = () => {
      const now = Date.now();
      const diffMinutes = Math.floor((now - lastActivity) / (1000 * 60));
      
      if (diffMinutes < 1) {
        setTimeAgo("just now");
      } else if (diffMinutes < 60) {
        setTimeAgo(`${diffMinutes}m ago`);
      } else {
        const diffHours = Math.floor(diffMinutes / 60);
        setTimeAgo(`${diffHours}h ago`);
      }
    };

    if (lastActivity > 0) {
      updateTimeAgo();
      const interval = setInterval(updateTimeAgo, 60000); // Update every minute
      return () => clearInterval(interval);
    }
  }, [lastActivity]);

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 mb-4">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isActive 
                ? 'bg-green-100 text-green-600' 
                : 'bg-gray-100 text-gray-500'
            }`}>
              <Bot className={`w-5 h-5 ${isActive ? 'animate-pulse' : ''}`} />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="font-semibold text-gray-800">TaskBot</h4>
                <Badge 
                  variant={isActive ? "default" : "secondary"}
                  className={isActive 
                    ? "bg-green-100 text-green-800 animate-pulse" 
                    : "bg-gray-100 text-gray-600"
                  }
                >
                  {isActive ? "Active" : "Idle"}
                </Badge>
              </div>
              <p className="text-xs text-gray-600">
                {lastActivity > 0 ? `Last active ${timeAgo}` : "Ready to generate tasks"}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 text-xs">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-1">
                <Zap className="w-3 h-3 text-yellow-500" />
                <span className="font-semibold text-gray-700">{tasksGenerated}</span>
              </div>
              <p className="text-gray-500">Generated</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center space-x-1">
                <TrendingUp className="w-3 h-3 text-blue-500" />
                <span className="font-semibold text-gray-700">AI</span>
              </div>
              <p className="text-gray-500">Powered</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}