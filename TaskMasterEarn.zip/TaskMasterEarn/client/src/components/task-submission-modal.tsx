import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Clock, Code, Send, CheckCircle } from "lucide-react";
import { Task } from "@/lib/types";

interface TaskSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (submission: string) => void;
  task: Task | null;
  isSubmitting?: boolean;
}

export default function TaskSubmissionModal({ 
  isOpen, 
  onClose, 
  onSubmit, 
  task, 
  isSubmitting = false 
}: TaskSubmissionModalProps) {
  const [submission, setSubmission] = useState("");

  const handleSubmit = () => {
    if (submission.trim()) {
      onSubmit(submission.trim());
      setSubmission("");
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!task) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Code className="w-5 h-5 text-primary" />
            <span>Complete Task</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Task Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-semibold text-gray-800 mb-2">{task.title}</h3>
            <p className="text-sm text-gray-600 mb-3">{task.description}</p>
            
            <div className="flex items-center space-x-3 mb-3">
              <Badge className={getDifficultyColor(task.difficulty || 'easy')}>
                {task.difficulty || 'easy'}
              </Badge>
              <div className="flex items-center text-sm text-gray-500">
                <Clock className="w-4 h-4 mr-1" />
                {task.estimatedTime || 15} min
              </div>
              <div className="text-sm font-semibold text-secondary">
                ₹{task.reward}
              </div>
            </div>
          </div>

          {/* Instructions */}
          {task.instructions && task.instructions.length > 0 && (
            <div>
              <h4 className="font-medium text-gray-800 mb-2">Instructions:</h4>
              <div className="space-y-2">
                {task.instructions.map((instruction, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm">
                    <span className="w-5 h-5 bg-primary rounded-full text-white text-xs flex items-center justify-center mt-0.5 flex-shrink-0">
                      {index + 1}
                    </span>
                    <span className="text-gray-600">{instruction}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Submission Area */}
          <div>
            <Label htmlFor="submission" className="font-medium text-gray-800 mb-2 block">
              Your Submission:
            </Label>
            <Textarea
              id="submission"
              placeholder={getPlaceholderText(task.type)}
              value={submission}
              onChange={(e) => setSubmission(e.target.value)}
              className="min-h-[120px] resize-none"
              rows={6}
            />
            <p className="text-xs text-gray-500 mt-2">
              Provide your complete solution above. Make sure to follow all instructions.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!submission.trim() || isSubmitting}
              className="flex-1 bg-secondary hover:bg-green-700"
            >
              {isSubmitting ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Submit Task
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function getPlaceholderText(taskType: string): string {
  switch (taskType.toLowerCase()) {
    case 'coding':
    case 'programming':
      return `// Write your code here
function chatbot(message) {
  // Your implementation
}`;
    case 'writing':
    case 'content_creation':
      return "Write your content here...";
    case 'research':
    case 'research_tasks':
      return "Share your research findings here...";
    case 'creative':
    case 'creative_tasks':
      return "Describe your creative solution here...";
    default:
      return "Enter your submission here...";
  }
}