import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle2, UserCheck, Coins, Smartphone, Share, DollarSign } from "lucide-react";

export default function HomePage() {
  const [, setLocation] = useLocation();

  const handleVerifyClick = () => {
    setLocation("/verification");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="gradient-bg text-white p-6 pb-12">
        <div className="text-center mt-8">
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 mx-auto shadow-lg">
            <CheckCircle2 className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Welcome to TaskForMe</h1>
          <p className="text-blue-100 mb-8">Complete simple tasks and earn money instantly</p>
        </div>
      </div>
      
      <div className="flex-1 -mt-6 bg-white rounded-t-3xl p-6">
        <div className="text-center">
          <div className="reward-gradient rounded-2xl p-6 mb-6 shadow-lg">
            <Coins className="w-16 h-16 text-white mb-3 mx-auto" />
            <h2 className="text-xl font-bold text-white mb-2">Start Earning Today</h2>
            <p className="text-yellow-100 text-sm">Verify your identity to unlock tasks worth ₹1-₹100 each</p>
          </div>
          
          <Button 
            onClick={handleVerifyClick}
            className="w-full bg-primary hover:bg-blue-700 text-white font-semibold py-4 px-6 h-auto text-base shadow-lg"
          >
            <UserCheck className="mr-2 h-5 w-5" />
            Verify ID to Start
          </Button>
          
          <div className="grid grid-cols-3 gap-4 mt-8">
            <div className="text-center p-4 bg-green-50 rounded-xl">
              <CheckCircle2 className="w-8 h-8 text-secondary mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-700">Simple Tasks</p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-xl">
              <DollarSign className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-700">Instant Rewards</p>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-xl">
              <Smartphone className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-700">Easy Withdrawal</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
