import { CheckCircle2 } from "lucide-react";

export default function SplashScreen() {
  return (
    <div className="fixed inset-0 gradient-bg flex flex-col items-center justify-center z-50">
      <div className="text-center animate-bounce-in">
        <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 mx-auto shadow-2xl">
          <CheckCircle2 className="w-12 h-12 text-primary" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-2">TaskForMe</h1>
        <p className="text-blue-100 text-lg font-medium">Earn by doing simple tasks</p>
      </div>
      <div className="absolute bottom-8 w-12 h-1 bg-white/30 rounded-full">
        <div className="h-full bg-white rounded-full loading-bar"></div>
      </div>
    </div>
  );
}
