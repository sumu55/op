import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Play, Camera, HelpCircle, Star } from "lucide-react";
import { getUserData, saveUserData } from "@/lib/storage";
import { UserData } from "@/lib/types";

export default function VerificationPage() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [userData, setUserData] = useState<UserData>(getUserData());
  const [timer, setTimer] = useState(5);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [profilePreview, setProfilePreview] = useState<string | null>(null);
  const [mathAnswer, setMathAnswer] = useState<string>("");
  const [colorAnswer, setColorAnswer] = useState<string>("");
  const [weekAnswer, setWeekAnswer] = useState<string>("");
  const [rating, setRating] = useState<number>(0);
  const [feedbackText, setFeedbackText] = useState<string>("");

  // Step 1: Ad timer
  useEffect(() => {
    if (currentStep === 1 && timer > 0) {
      const interval = setInterval(() => {
        setTimer(prev => prev - 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [currentStep, timer]);

  const handleBack = () => {
    setLocation("/");
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setProfilePreview(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStarClick = (starRating: number) => {
    setRating(starRating);
  };

  const canProceedStep2 = selectedFile && profilePreview;
  const canProceedStep3 = mathAnswer && colorAnswer && weekAnswer;

  const completeVerification = () => {
    const updatedUserData: UserData = {
      ...userData,
      verified: true,
      profilePic: profilePreview,
      answers: {
        math: mathAnswer,
        color: colorAnswer,
        week: weekAnswer,
      },
      feedback: {
        rating,
        text: feedbackText,
      },
    };
    
    setUserData(updatedUserData);
    saveUserData(updatedUserData);
    setLocation("/dashboard");
  };

  const renderProgressBar = () => (
    <div className="gradient-bg p-4">
      <div className="flex items-center justify-between mb-4">
        <Button variant="ghost" size="icon" onClick={handleBack} className="text-white">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h2 className="text-white font-semibold">Verification</h2>
        <div className="w-6"></div>
      </div>
      <div className="flex space-x-2">
        {[1, 2, 3, 4].map((step) => (
          <div
            key={step}
            className={`flex-1 h-2 rounded-full ${
              step <= currentStep ? 'bg-blue-300' : 'bg-blue-300/30'
            }`}
          />
        ))}
      </div>
    </div>
  );

  const renderStep1 = () => (
    <div className="p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Play className="w-8 h-8 text-red-500" />
        </div>
        <h3 className="text-xl font-bold text-gray-800 mb-2">Watch Advertisement</h3>
        <p className="text-gray-600">Please watch this short ad to continue</p>
      </div>
      
      <div className="bg-gray-100 rounded-xl p-8 mb-6 text-center">
        <div className="bg-gradient-to-r from-purple-400 to-pink-400 text-white p-6 rounded-lg">
          <Play className="w-12 h-12 mb-3 mx-auto" />
          <p className="font-medium">Advertisement Loading...</p>
          <p className="text-sm mt-2 opacity-90">Adsterra ad will appear here</p>
        </div>
        <script type='text/javascript' src='//pl26964362.profitableratecpm.com/b8/31/f9/b831f983fd1d5d687e203c7813aa8ac2.js'></script>
      </div>
      
      <Button 
        onClick={() => setCurrentStep(2)}
        disabled={timer > 0}
        className="w-full"
      >
        {timer > 0 ? `Wait ${timer} seconds...` : 'Continue'}
      </Button>
    </div>
  );

  const renderStep2 = () => (
    <div className="p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Camera className="w-8 h-8 text-primary" />
        </div>
        <h3 className="text-xl font-bold text-gray-800 mb-2">Upload Profile Picture</h3>
        <p className="text-gray-600">Add a photo to personalize your profile</p>
      </div>
      
      <div className="text-center mb-6">
        <div className="w-32 h-32 bg-gray-100 rounded-full mx-auto mb-4 flex items-center justify-center border-4 border-dashed border-gray-300 overflow-hidden">
          {profilePreview ? (
            <img src={profilePreview} alt="Profile" className="w-full h-full object-cover rounded-full" />
          ) : (
            <Camera className="w-16 h-16 text-gray-400" />
          )}
        </div>
        <input 
          type="file" 
          id="profilePicture" 
          accept="image/*" 
          className="hidden"
          onChange={handleFileUpload}
        />
        <Button 
          onClick={() => document.getElementById('profilePicture')?.click()}
          className="success-gradient text-white"
        >
          <Camera className="mr-2 h-4 w-4" />
          Choose Photo
        </Button>
      </div>
      
      <Button 
        onClick={() => setCurrentStep(3)}
        disabled={!canProceedStep2}
        className="w-full"
      >
        Continue
      </Button>
    </div>
  );

  const renderStep3 = () => (
    <div className="p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <HelpCircle className="w-8 h-8 text-secondary" />
        </div>
        <h3 className="text-xl font-bold text-gray-800 mb-2">Quick Questions</h3>
        <p className="text-gray-600">Answer these simple questions</p>
      </div>
      
      <div className="space-y-6">
        <div className="bg-white rounded-xl p-4 shadow-sm border">
          <p className="font-medium text-gray-800 mb-3">1. What is 2 + 2?</p>
          <div className="grid grid-cols-2 gap-3">
            {['3', '4', '5', '6'].map((option) => (
              <Button
                key={option}
                variant={mathAnswer === option ? "default" : "outline"}
                onClick={() => setMathAnswer(option)}
                className="p-3"
              >
                {option}
              </Button>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-4 shadow-sm border">
          <Label htmlFor="colorAnswer" className="font-medium text-gray-800 mb-3 block">
            2. What's your favorite color?
          </Label>
          <Input
            id="colorAnswer"
            placeholder="Enter your answer..."
            value={colorAnswer}
            onChange={(e) => setColorAnswer(e.target.value)}
          />
        </div>
        
        <div className="bg-white rounded-xl p-4 shadow-sm border">
          <Label htmlFor="weekAnswer" className="font-medium text-gray-800 mb-3 block">
            3. How many days in a week?
          </Label>
          <Select value={weekAnswer} onValueChange={setWeekAnswer}>
            <SelectTrigger>
              <SelectValue placeholder="Select answer..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5">5</SelectItem>
              <SelectItem value="6">6</SelectItem>
              <SelectItem value="7">7</SelectItem>
              <SelectItem value="8">8</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Button 
        onClick={() => setCurrentStep(4)}
        disabled={!canProceedStep3}
        className="w-full mt-6"
      >
        Continue
      </Button>
    </div>
  );

  const renderStep4 = () => (
    <div className="p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Star className="w-8 h-8 text-accent" />
        </div>
        <h3 className="text-xl font-bold text-gray-800 mb-2">Your Feedback</h3>
        <p className="text-gray-600">How was your onboarding experience?</p>
      </div>
      
      <div className="bg-white rounded-xl p-6 shadow-sm border mb-6">
        <p className="font-medium text-gray-800 mb-4">Rate your experience:</p>
        <div className="flex justify-center space-x-2 mb-6">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={`w-8 h-8 cursor-pointer ${
                star <= rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
              }`}
              onClick={() => handleStarClick(star)}
            />
          ))}
        </div>
        
        <Textarea
          placeholder="Tell us about your experience (optional)..."
          value={feedbackText}
          onChange={(e) => setFeedbackText(e.target.value)}
          className="resize-none"
          rows={3}
        />
      </div>
      
      <Button 
        onClick={completeVerification}
        className="w-full success-gradient text-white"
      >
        Complete Verification
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {renderProgressBar()}
      
      {currentStep === 1 && renderStep1()}
      {currentStep === 2 && renderStep2()}
      {currentStep === 3 && renderStep3()}
      {currentStep === 4 && renderStep4()}
    </div>
  );
}
