import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Settings, Wallet, User, Bot, RefreshCw } from "lucide-react";
import { getUserData, saveUserData, getTasks, saveTasks, generateTasks } from "@/lib/storage";
import { UserData, Task, TaskPerformance } from "@/lib/types";
import WithdrawModal from "@/components/withdraw-modal";
import SuccessModal from "@/components/success-modal";
import TaskCard from "@/components/task-card";
import TaskBotStatus from "@/components/task-bot-status";
import NotificationBell from "@/components/notification-bell";
import TaskSubmissionModal from "@/components/task-submission-modal";
import BackgroundTaskGenerator from "@/components/background-task-generator";
import { useToast } from "@/hooks/use-toast";
import { taskBot } from "@/lib/geminiApi";
import { taskQueue } from "@/lib/taskQueue";
import { realTaskGenerator } from "@/lib/realTaskGenerator";
import { taskReviewer } from "@/lib/taskReviewer";

export default function DashboardPage() {
  const [userData, setUserData] = useState<UserData>(getUserData());
  const [tasks, setTasks] = useState<Task[]>([]);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);  
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [completingTask, setCompletingTask] = useState<string | null>(null);
  const [isGeneratingTasks, setIsGeneratingTasks] = useState(false);
  const [botStats, setBotStats] = useState({ tasksGenerated: 0, lastActivity: 0 });
  const [newTaskCount, setNewTaskCount] = useState(0);
  const [showSubmissionModal, setShowSubmissionModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    let savedTasks = getTasks();
    if (savedTasks.length === 0) {
      generateAITasks();
    } else {
      setTasks(savedTasks);
    }

    const handleNewTasks = (updatedTasks: Task[]) => {
      setTasks(updatedTasks);
      const pendingTasks = updatedTasks.filter(t => t.status === 'pending');
      setNewTaskCount(pendingTasks.length);
    };

    const handleNotification = (message: string) => {
      toast({
        title: "TaskBot Alert",
        description: message,
        duration: 4000,
      });
      setNewTaskCount(prev => prev + 1);
    };

    taskQueue.addTaskListener(handleNewTasks);
    taskQueue.addNotificationListener(handleNotification);
    taskQueue.startAutoGeneration(15);

    return () => {
      taskQueue.removeTaskListener(handleNewTasks);
      taskQueue.removeNotificationListener(handleNotification);
    };
  }, [toast]);

  const generateAITasks = async () => {
    setIsGeneratingTasks(true);
    try {
      const realTasks = await realTaskGenerator.generatePersonalizedRealTasks(userData);
      
      if (realTasks.length > 0) {
        setTasks(realTasks);
        saveTasks(realTasks);
        
        setBotStats(prev => ({
          tasksGenerated: prev.tasksGenerated + realTasks.length,
          lastActivity: Date.now()
        }));
        
        toast({
          title: "Real Tasks Generated!",
          description: `TaskBot created ${realTasks.length} personalized tasks based on your performance`,
          duration: 4000,
        });
      } else {
        throw new Error('No real tasks generated');
      }
    } catch (error) {
      console.error('Failed to generate real tasks:', error);
      const fallbackTasks = generateTasks();
      setTasks(fallbackTasks);
      saveTasks(fallbackTasks);
      
      toast({
        title: "Fallback Tasks Loaded",
        description: "Real task generation failed, using default tasks",
        duration: 3000,
      });
    }
    setIsGeneratingTasks(false);
  };

  const getIconForCategory = (category: string): string => {
    const categoryIcons = {
      'Social media engagement': 'Share',
      'Content creation': 'MessageCircle',
      'Learning activities': 'Play',
      'Survey participation': 'ClipboardList',
      'App testing': 'Sparkles',
      'Data entry': 'UserCheck',
      'Creative tasks': 'Star',
      'Research tasks': 'CalendarCheck',
    };
    return categoryIcons[category as keyof typeof categoryIcons] || 'Play';
  };

  const handleAcceptTask = (taskId: string) => {
    const updatedTasks = tasks.map(task => 
      task.id === taskId 
        ? { ...task, status: 'accepted' as const, acceptedAt: Date.now() }
        : task
    );
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
    
    toast({
      title: "Task Accepted!",
      description: "You can now complete this task to earn rewards",
      duration: 2000,
    });
  };

  const handleRejectTask = (taskId: string) => {
    const updatedTasks = tasks.map(task => 
      task.id === taskId 
        ? { ...task, status: 'rejected' as const }
        : task
    );
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
    
    toast({
      title: "Task Rejected",
      description: "Task has been removed from your list",
      duration: 2000,
    });
  };

  const handleCompleteTask = async (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    if (task.type === 'coding' || task.type === 'programming' || task.type === 'writing' || task.type === 'creative') {
      setSelectedTask(task);
      setShowSubmissionModal(true);
      return;
    }

    setCompletingTask(taskId);
    await new Promise(resolve => setTimeout(resolve, 2000));
    completeTask(task);
    setCompletingTask(null);
  };

  const handleTaskSubmission = async (submission: string) => {
    if (!selectedTask) return;

    setIsSubmitting(true);
    
    const updatedTasks = tasks.map(t => 
      t.id === selectedTask.id 
        ? { ...t, status: 'submitted' as const, submittedAt: Date.now(), submission }
        : t
    );
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
    
    toast({
      title: "Task Submitted!",
      description: "Your submission is being reviewed by TaskBot...",
      duration: 3000,
    });

    try {
      const reviewResult = await taskReviewer.reviewTaskSubmission(selectedTask, submission);
      
      const reviewedTasks = tasks.map(t => 
        t.id === selectedTask.id 
          ? { 
              ...t, 
              status: reviewResult.approved ? 'completed' as const : 'rejected' as const,
              completedAt: reviewResult.approved ? Date.now() : undefined,
              reviewScore: reviewResult.score,
              reviewFeedback: reviewResult.feedback,
              reward: reviewResult.earnedAmount,
              completed: reviewResult.approved
            }
          : t
      );
      setTasks(reviewedTasks);
      saveTasks(reviewedTasks);

      if (reviewResult.approved) {
        const taskPerformance: TaskPerformance = {
          taskId: selectedTask.id,
          score: reviewResult.score,
          completedAt: Date.now(),
          taskType: selectedTask.type,
          earnedAmount: reviewResult.earnedAmount
        };

        const updatedUserData = taskReviewer.updateUserPerformance(userData, taskPerformance);
        updatedUserData.balance += reviewResult.earnedAmount;
        
        setUserData(updatedUserData);
        saveUserData(updatedUserData);

        toast({
          title: "Task Approved!",
          description: `Score: ${reviewResult.score}/100. Earned ₹${reviewResult.earnedAmount}`,
          duration: 5000,
        });
      } else {
        toast({
          title: "Task Rejected",
          description: reviewResult.feedback,
          duration: 5000,
        });
      }
      
    } catch (error) {
      console.error('Review failed:', error);
      completeTask(selectedTask);
    }
    
    setIsSubmitting(false);
    setShowSubmissionModal(false);
    setSelectedTask(null);
  };

  const completeTask = (task: Task) => {
    const updatedUserData = {
      ...userData,
      balance: userData.balance + task.reward,
      tasksCompleted: userData.tasksCompleted + 1,
    };
    
    setUserData(updatedUserData);
    saveUserData(updatedUserData);
    
    const updatedTasks = tasks.map(t => 
      t.id === task.id 
        ? { ...t, status: 'completed' as const, completedAt: Date.now(), completed: true }
        : t
    );
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
    
    const activeTasks = updatedTasks.filter(t => t.status === 'pending' || t.status === 'accepted');
    if (activeTasks.length < 2) {
      taskQueue.generateBackgroundTasks();
    }
    
    toast({
      title: "Task Completed!",
      description: `You earned ₹${task.reward}`,
      duration: 3000,
    });
  };

  const handleWithdrawSuccess = () => {
    const updatedUserData = {
      ...userData,
      balance: 0,
    };
    setUserData(updatedUserData);
    saveUserData(updatedUserData);
    setShowWithdrawModal(false);
    setShowSuccessModal(true);
  };

  const getIconForCategory = (category: string): string => {
    const categoryIcons = {
      'Social media engagement': 'Share',
      'Content creation': 'MessageCircle',
      'Learning activities': 'Play',
      'Survey participation': 'ClipboardList',
      'App testing': 'Sparkles',
      'Data entry': 'UserCheck',
      'Creative tasks': 'Star',
      'Research tasks': 'CalendarCheck',
    };
    return categoryIcons[category as keyof typeof categoryIcons] || 'Play';
  };

  const handleAcceptTask = (taskId: string) => {
    const updatedTasks = tasks.map(task => 
      task.id === taskId 
        ? { ...task, status: 'accepted' as const, acceptedAt: Date.now() }
        : task
    );
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
    
    toast({
      title: "Task Accepted!",
      description: "You can now complete this task to earn rewards",
      duration: 2000,
    });
  };

  const handleRejectTask = (taskId: string) => {
    const updatedTasks = tasks.map(task => 
      task.id === taskId 
        ? { ...task, status: 'rejected' as const }
        : task
    );
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
    
    toast({
      title: "Task Rejected",
      description: "Task has been removed from your list",
      duration: 2000,
    });
  };

  const handleCompleteTask = async (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    // For tasks that require submission (coding, writing, etc.)
    if (task.type === 'coding' || task.type === 'programming' || task.type === 'writing' || task.type === 'creative') {
      setSelectedTask(task);
      setShowSubmissionModal(true);
      return;
    }

    // For simple tasks, complete immediately
    setCompletingTask(taskId);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    completeTask(task);
    setCompletingTask(null);
  };

  const handleTaskSubmission = async (submission: string) => {
    if (!selectedTask) return;

    setIsSubmitting(true);
    
    // Simulate submission processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    completeTask(selectedTask);
    
    setIsSubmitting(false);
    setShowSubmissionModal(false);
    setSelectedTask(null);
  };

  const completeTask = (task: Task) => {
    // Update user balance
    const updatedUserData = {
      ...userData,
      balance: userData.balance + task.reward,
      tasksCompleted: userData.tasksCompleted + 1,
    };
    
    setUserData(updatedUserData);
    saveUserData(updatedUserData);
    
    // Mark task as completed
    const updatedTasks = tasks.map(t => 
      t.id === task.id 
        ? { ...t, status: 'completed' as const, completedAt: Date.now(), completed: true }
        : t
    );
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
    
    // Generate new tasks if running low
    const activeTasks = updatedTasks.filter(t => t.status === 'pending' || t.status === 'accepted');
    if (activeTasks.length < 2) {
      taskQueue.generateBackgroundTasks();
    }
    
    // Show success toast
    toast({
      title: "Task Completed!",
      description: `You earned ₹${task.reward}`,
      duration: 3000,
    });
  };

  const handleWithdrawSuccess = () => {
    const updatedUserData = {
      ...userData,
      balance: 0,
    };
    setUserData(updatedUserData);
    saveUserData(updatedUserData);
    setShowWithdrawModal(false);
    setShowSuccessModal(true);
  };



  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="gradient-bg text-white p-6 pb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center overflow-hidden">
              {userData.profilePic ? (
                <img src={userData.profilePic} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-6 h-6 text-primary" />
              )}
            </div>
            <div>
              <p className="text-blue-100 text-sm">Welcome back</p>
              <h2 className="font-bold text-lg">{userData.name} 👋</h2>
            </div>
          </div>
          <NotificationBell
            hasNewTasks={newTaskCount > 0}
            newTaskCount={newTaskCount}
            onClick={() => setNewTaskCount(0)}
          />
        </div>
      </div>

      {/* Wallet Card */}
      <div className="px-6 -mt-4 mb-6">
        <Card className="shadow-lg border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-gray-600 text-sm mb-1">Your Wallet Balance</p>
                <h3 className="text-3xl font-bold text-gray-800">₹{userData.balance}</h3>
              </div>
              <div className="w-16 h-16 reward-gradient rounded-full flex items-center justify-center">
                <Wallet className="w-8 h-8 text-white" />
              </div>
            </div>
            <Button 
              onClick={() => setShowWithdrawModal(true)}
              className="w-full success-gradient text-white font-semibold py-3"
              disabled={userData.balance === 0}
            >
              <Wallet className="mr-2 h-4 w-4" />
              Withdraw Money
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* TaskBot Status */}
      <div className="px-6">
        <TaskBotStatus 
          tasksGenerated={botStats.tasksGenerated}
          isActive={isGeneratingTasks}
          lastActivity={botStats.lastActivity}
        />
      </div>

      {/* Tasks Section */}
      <div className="px-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <h3 className="text-xl font-bold text-gray-800">Available Tasks</h3>
            <Bot className="w-5 h-5 text-primary" />
          </div>
          <Button
            onClick={generateAITasks}
            disabled={isGeneratingTasks}
            size="sm"
            variant="outline"
            className="text-xs"
          >
            {isGeneratingTasks ? (
              <>
                <RefreshCw className="mr-1 h-3 w-3 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <RefreshCw className="mr-1 h-3 w-3" />
                New Tasks
              </>
            )}
          </Button>
        </div>
        
        {isGeneratingTasks && tasks.length === 0 ? (
          <div className="text-center py-8">
            <Bot className="w-12 h-12 text-primary mx-auto mb-3 animate-pulse" />
            <p className="text-gray-600">TaskBot is creating personalized tasks for you...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {tasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onAccept={handleAcceptTask}
                onReject={handleRejectTask}
                onComplete={handleCompleteTask}
                isProcessing={completingTask === task.id}
              />
            ))}
            
            {tasks.length === 0 && !isGeneratingTasks && (
              <div className="text-center py-8">
                <Bot className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 mb-4">No tasks available</p>
                <Button onClick={generateAITasks} className="bg-primary">
                  <Bot className="mr-2 h-4 w-4" />
                  Get New Tasks
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      <WithdrawModal
        isOpen={showWithdrawModal}
        onClose={() => setShowWithdrawModal(false)}
        onSuccess={handleWithdrawSuccess}
        currentBalance={userData.balance}
      />
      
      <SuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
      />
      
      <TaskSubmissionModal
        isOpen={showSubmissionModal}
        onClose={() => setShowSubmissionModal(false)}
        onSubmit={handleTaskSubmission}
        task={selectedTask}
        isSubmitting={isSubmitting}
      />

      {/* Background Task Generator - runs silently */}
      <BackgroundTaskGenerator isActive={userData.verified} />
    </div>
  );
}
